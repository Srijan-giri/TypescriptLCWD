var address = "Mumbai";
console.log(typeof address);
var password;
password = "ABC24424";
password = 2315231;
console.log(typeof password);
