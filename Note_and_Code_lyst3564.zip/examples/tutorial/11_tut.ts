//enum example

// name of days

//sytax:

enum DAYS {
  MON,
  TUE,
  WED,
  THU,
  FRI,
  SAT,
  SUN,
}
enum Months {
  Jan,
  Feb,
  Mar,
  Apr,
  May,
  Jun,
  Jul,
  Aug,
  Sep,
  Oct,
  Nov,
  Dec,
}

enum OrderStatus {
  PENDING,
  DELIVERED,
  DISPATCH,
}

function myFun(value: Months) {
  switch (value) {
    case Months.Jan:
      console.log("This is first month of year");
      break;

    case Months.Feb:
      console.log("this is second month of year");
      break;

    default:
      console.log("Not valid month");
  }
}

myFun(Months.Dec);

let order: { title: string; price: number; status: OrderStatus; date: Date };

order = {
  title: "Samsung TV1234",
  price: 33000.56,
  status: OrderStatus.PENDING,
  date: new Date(),
};

console.log(order);
order.status = OrderStatus.DISPATCH;
console.log(order);

console.log(OrderStatus);
