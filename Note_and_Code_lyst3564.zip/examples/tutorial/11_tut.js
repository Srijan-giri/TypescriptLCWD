//enum example
// name of days
//sytax:
var DAYS;
(function (DAYS) {
    DAYS[DAYS["MON"] = 0] = "MON";
    DAYS[DAYS["TUE"] = 1] = "TUE";
    DAYS[DAYS["WED"] = 2] = "WED";
    DAYS[DAYS["THU"] = 3] = "THU";
    DAYS[DAYS["FRI"] = 4] = "FRI";
    DAYS[DAYS["SAT"] = 5] = "SAT";
    DAYS[DAYS["SUN"] = 6] = "SUN";
})(DAYS || (DAYS = {}));
var Months;
(function (Months) {
    Months[Months["Jan"] = 0] = "Jan";
    Months[Months["Feb"] = 1] = "Feb";
    Months[Months["Mar"] = 2] = "Mar";
    Months[Months["Apr"] = 3] = "Apr";
    Months[Months["May"] = 4] = "May";
    Months[Months["Jun"] = 5] = "Jun";
    Months[Months["Jul"] = 6] = "Jul";
    Months[Months["Aug"] = 7] = "Aug";
    Months[Months["Sep"] = 8] = "Sep";
    Months[Months["Oct"] = 9] = "Oct";
    Months[Months["Nov"] = 10] = "Nov";
    Months[Months["Dec"] = 11] = "Dec";
})(Months || (Months = {}));
var OrderStatus;
(function (OrderStatus) {
    OrderStatus[OrderStatus["PENDING"] = 0] = "PENDING";
    OrderStatus[OrderStatus["DELIVERED"] = 1] = "DELIVERED";
    OrderStatus[OrderStatus["DISPATCH"] = 2] = "DISPATCH";
})(OrderStatus || (OrderStatus = {}));
function myFun(value) {
    switch (value) {
        case Months.Jan:
            console.log("This is first month of year");
            break;
        case Months.Feb:
            console.log("this is second month of year");
            break;
        default:
            console.log("Not valid month");
    }
}
myFun(Months.Dec);
var order;
order = {
    title: "Samsung TV1234",
    price: 33000.56,
    status: OrderStatus.PENDING,
    date: new Date(),
};
console.log(order);
order.status = OrderStatus.DISPATCH;
console.log(order);
console.log(OrderStatus);
