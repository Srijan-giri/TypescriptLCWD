let userName: null = null;
console.log(userName);
console.log(typeof userName);

let userPassword;
console.log(userPassword);
console.log(typeof userPassword);

if (userName) {
  console.log("TRUE USERNAME");
} else {
  console.log("FALSE USERNAME");
}
if (userPassword) {
  console.log("TRUE PASSWORD");
} else {
  console.log("FALSE PASSWORD");
}

let networkData: any = {
  productName: "Samsung TV",
  price: 321425,
  discountedPrice: 2354,
};

console.log(networkData.productName);
console.log(networkData.isActive);
