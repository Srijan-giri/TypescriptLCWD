let student: {
  name: string;
  address: string;
  phone: number;
  isActive: boolean;
} = {
  name: "Ankit",
  address: "Gomti Nagar Lucknow",
  phone: 213452,
  isActive: true,
};

console.log(student);
console.log(student.name);
console.log(student.address);
console.log(typeof student);

let person = {};
// object vs Object
