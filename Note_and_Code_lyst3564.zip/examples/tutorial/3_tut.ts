//explict annotate
let userName: string = "Uttam";

//Implicit
let password = "abc@123";
let address: string;
address = "delhi";

let userAge: number = 24;
let salary: number = 1235235.123523;
userName.toLowerCase();
// userAge.toLowerCase()

let isActive: boolean = true;
isActive = false;

isActive = true;

console.log(typeof userName);
console.log(typeof password);
console.log(typeof userAge);

let userEmail = "abc@gmail.com";
let userDetailDescription = ` User is programmer . email id is ${userEmail}. user name is ${userName}`;
console.log(userEmail);
console.log(userDetailDescription);

// string, number , boolean
