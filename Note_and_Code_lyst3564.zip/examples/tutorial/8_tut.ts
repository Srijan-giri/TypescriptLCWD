// store user id
let userId: string | number = "q5fsdgfafaf";
userId = 23523562;
userId = "sdgsagsagsgas";
userId = 2352521356;

// display user id and return
function displayUserId(userId: string | number): string | number {
  console.log("user id is " + userId);
  if (typeof userId === "string") {
    console.log(userId.toUpperCase);
  }
  return userId;
}

displayUserId(userId);

let myArray: (string | number)[] = ["one", 1, "two", 2];
