//explict annotate
var userName = "Uttam";
//Implicit
var password = "abc@123";
var address;
address = "delhi";
var userAge = 24;
var salary = 1235235.123523;
userName.toLowerCase();
// userAge.toLowerCase()
var isActive = true;
isActive = false;
isActive = true;
console.log(typeof userName);
console.log(typeof password);
console.log(typeof userAge);
var userEmail = "abc@gmail.com";
var userDetailDescription = " User is programmer . email id is ".concat(userEmail, ". user name is ").concat(userName);
console.log(userEmail);
console.log(userDetailDescription);
