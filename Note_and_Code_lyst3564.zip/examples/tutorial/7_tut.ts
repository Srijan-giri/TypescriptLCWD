//function creation

// formal parameters
function ramu(rs: number, name: string): number {
  console.log("hello sir g , what can i do for you?");
  return 4;
}

// function calling

// actual parameters
let ng = ramu(12, "left");
console.log(ng);

ramu(15, "center");
ramu(450, "right");
