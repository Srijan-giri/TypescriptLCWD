// function sumOfThree(a: number, b: number, c?: number, d?: number): number {
//   console.log("Adding three numbers");
//   if (c !== undefined) {
//     return a + b + c;
//   }
//   return a + b;
// }

// console.log(sumOfThree(1, 2));
// console.log(sumOfThree(1, 2, 67));
// function sumOfThree(a: number = 1, b: number, c: number = 1): number {
//   console.log("Adding three numbers");
//   return a + b + c;
// }

// console.log(sumOfThree(undefined, 2));
// console.log(sumOfThree(1, 2, 67));

function sumAtLeastTwo(a: number, b: number, ...rest: number[]): number {
  let sum = a + b;

  rest.forEach((n) => {
    sum = sum + n;
  });
  console.log("sum is ", sum);

  return sum;
}

sumAtLeastTwo(12, 12);
sumAtLeastTwo(12, 12, 23, 12, 35, 34, 46, 57);
sumAtLeastTwo(1, 2, 3);
