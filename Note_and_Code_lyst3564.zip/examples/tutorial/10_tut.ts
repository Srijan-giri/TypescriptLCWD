// tuple

let skill: [string, number] = ["programming", 400];
console.log(skill);

console.log(skill[0]);
console.log(skill[1]);

// (rgba)
let color: [number, number, number, number] = [255, 255, 0, 0.8];

console.log("current color is ", color);
// optional Tuple:
let color1: [number, number, number, number?] = [255, 255, 0];
