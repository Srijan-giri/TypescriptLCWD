var x = function myFun(a, b) {
    return a + b;
};
var person;
person = {
    firstName: "durgesh",
    lastName: "tiwari",
    getFullName: function () {
        return this.firstName + " " + this.lastName;
    },
};
console.log(person.getFullName());
