console.log("this is my first typescript code");
// all typescript code goes here
console.log("wow its amazing");
class Test {}
let ob: Test = new Test();
console.log("this is  testing again");
let firstName = "durgesh tiwari";
console.log(typeof firstName);
// firstName = 23;
alert("this is testing");
