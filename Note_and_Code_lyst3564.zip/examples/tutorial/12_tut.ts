type xyz = string;
let address: xyz = "Mumbai";
console.log(typeof address);

type aphaNum = string | number;
let password: aphaNum;
password = "ABC24424";
password = 2315231;
console.log(typeof password);

type Order = {
  title: string;
  price: number;
  status: string;
};

let order1: Order;

order1 = {
  title: "This is title of order",
  price: 123523,
  status: "this is status",
};
