// tuple
var skill = ["programming", 400];
console.log(skill);
console.log(skill[0]);
console.log(skill[1]);
// (rgba)
var color = [255, 255, 0];
console.log("current color is ", color);
