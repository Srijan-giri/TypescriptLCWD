let numbers: number[] = [12, 45, 67, 21];
console.log(numbers);
console.log(numbers[0]);
console.log(numbers[2]);
numbers[1] = 4545;
console.log(numbers);

let friends: string[];
friends = ["Gautam", "Ashutosh", "Kavish"];
console.log(friends);

// length
console.log(numbers.length);
for (let i = 0; i < numbers.length; i++) {
  console.log(numbers[i]);
}

//push
let newLength: number = friends.push("Shivam");
console.log("Array Number length: " + newLength);
console.log(friends);

console.log(typeof numbers);
console.log(typeof numbers[0]);
console.log(typeof friends[0]);

console.log(friends.join("----"));

friends.forEach((value, index) => {
  console.log(index, value.toUpperCase());
});

let newFriends = friends.map((value, index) => {
  console.log(value);
  return value.toUpperCase();
});
console.log(newFriends);

let mixed: (string | number)[];

mixed = ["one", "two", "three", 23, 35];

mixed.forEach((value) => {
  if (typeof value == "string") {
    console.log(value.toUpperCase);
  } else {
    console.log(value.toFixed(2));
  }
});

console.log(mixed);
