var userName;
userName = "durgesh";
userName = "harsh";
userName = "ankit";
console.log(userName);
console.log(typeof userName);
