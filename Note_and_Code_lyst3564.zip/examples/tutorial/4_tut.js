var userName = null;
console.log(userName);
console.log(typeof userName);
var userPassword;
console.log(userPassword);
console.log(typeof userPassword);
if (userName) {
    console.log("TRUE USERNAME");
}
else {
    console.log("FALSE USERNAME");
}
if (userPassword) {
    console.log("TRUE PASSWORD");
}
else {
    console.log("FALSE PASSWORD");
}
var networkData = {
    productName: "Samsung TV",
    price: 321425,
    discountedPrice: 2354,
};
console.log(networkData.productName);
console.log(networkData.isActive);
