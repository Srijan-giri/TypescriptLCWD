// let x: void;

// x = undefined;

//  strictNullChecks is set to false in tsconfig.json: then void mein assign null
// x = null;
// void no data

// explicit: void
function myFun(a: number, b: number): void {
  console.log("sum is ", a + b);
}

// implicit infer
function myFun2() {}

// void: null or undefined

// never:

function myFun3(): never {
  throw new Error("This is my error");
}

// unknown

function myFun4() {
  return "this is value ";
}

let value: unknown = myFun4();
let value1: any = myFun4();
// console.log(value1.toUpperCase());
// console.log(value.toUpperCase());

let valueInString: string = value as string;
console.log(valueInString.toUpperCase());
