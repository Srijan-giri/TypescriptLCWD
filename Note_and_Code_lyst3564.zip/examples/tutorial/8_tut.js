var userId;
console.log(userId);
