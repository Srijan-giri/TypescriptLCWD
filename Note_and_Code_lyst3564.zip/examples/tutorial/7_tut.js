function ramu() {
    console.log("hello sir g , what can i do for you?");
}
ramu();
ramu();
