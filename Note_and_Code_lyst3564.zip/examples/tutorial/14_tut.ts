let x: (x: number, y: number) => number = function myFun(
  a: number,
  b: number
): number {
  return a + b;
};

let person: {
  firstName: string;
  lastName: string;
  getFullName: () => string;
};

person = {
  firstName: "durgesh",
  lastName: "tiwari",
  getFullName: function () {
    return this.firstName + " " + this.lastName;
  },
};

console.log(person.getFullName());
