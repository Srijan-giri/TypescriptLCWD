abstract class Animal {
  abstract eat(): string;
  display() {
    console.log("this is diplay method of abstract class");
  }
}

class Dog extends Animal {
  eat(): string {
    return "dog is eating";
  }
}

let anim = new Dog();
anim.display();
console.log(anim.eat());
