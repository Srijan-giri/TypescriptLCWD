var PointImpl = /** @class */ (function () {
    function PointImpl(x, y) {
        this.x = x;
        this.y = y;
    }
    PointImpl.prototype.displayCoordinates = function () {
        console.log("( ".concat(this.x, " , ").concat(this.y, " )"));
    };
    return PointImpl;
}());
function findDistance(point1, point2) {
    point1.displayCoordinates();
    point2.displayCoordinates();
    // calculate the distance
    var yR = Math.pow(point2.y - point1.y, 2);
    var xR = Math.pow(point2.x - point1.x, 2);
    var d = Math.sqrt(xR + yR);
    console.log("Distance : " + d.toFixed(2));
}
// calling the method to calculate the distance
findDistance(new PointImpl(-7, -4), new PointImpl(17, 6.5));
findDistance(new PointImpl(10, -4), new PointImpl(45, 6.5));
