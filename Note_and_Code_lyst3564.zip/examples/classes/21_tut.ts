class Employee {
  name: string;
  phone: string;
  empId: string;
  address: string;
  displayName() {
    console.log(`my name is ${this.name}`);
  }
}

class Manager extends Employee {
  managerTask: string;
  displayNameWithTask() {
    this.displayName();
    console.log("task is " + this.managerTask);
  }
}

class Developer extends Employee {
  technology: string;
  project: string;
  displayProjectWithName() {
    this.displayName();
    console.log("project detail is " + this.project);
  }
}

let androidDevelper = new Developer();

androidDevelper.name = "RAM";
androidDevelper.phone = "q3w525";
androidDevelper.project = "ANdroid social site";
androidDevelper.technology = "Android using Flutter";

androidDevelper.displayName();
androidDevelper.displayProjectWithName();
