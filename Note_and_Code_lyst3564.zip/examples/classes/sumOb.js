var Sum = /** @class */ (function () {
    function Sum(a, b) {
        if (this._a < 0 || this._b < 0) {
            console.log("Negative values not allowed !!");
            throw new Error("Error in creating Object : No Negative values allowed");
        }
        this._a = a;
        this._b = b;
        console.log("Creating object of sum");
    }
    Object.defineProperty(Sum.prototype, "a", {
        //getters
        get: function () {
            // any validation
            console.log("Validating a");
            return this._a;
        },
        //setters
        set: function (a) {
            console.log("Setter a");
            if (this._a < 0) {
                console.log("Only positive values are allowed !!");
                return;
            }
            this._a = a;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Sum.prototype, "b", {
        get: function () {
            //any validation
            console.log("validating b");
            return this._b;
        },
        set: function (b) {
            console.log("setter b");
            if (this._b < 0) {
                console.log("Only positive values are allowed !!");
                return;
            }
            this._b = b;
        },
        enumerable: false,
        configurable: true
    });
    Sum.prototype.sum = function () {
        return this._a + this._b;
    };
    Sum.prototype.display = function () {
        console.log("Value of a ", this.a);
        console.log("Value of b ", this.b);
    };
    return Sum;
}());
var ob = new Sum(34, 45);
ob.display();
ob.a = -9056;
ob.b = 34534;
ob.display();
console.log(ob.a);
console.log(ob.b);
