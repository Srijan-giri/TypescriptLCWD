class Car {
  color: string;
  constructor(color: string) {
    this.color = color;
    console.log("creating car object");
  }

  //   methods

  start() {
    console.log("starting car");
  }

  sumTwoNumber(a: number, b: number): number {
    console.log("Adding two number");
    return a + b;
  }
}

//creating object

let ob1: Car = new Car("Black");
console.log(ob1.color);
ob1.start();
let answer = ob1.sumTwoNumber(34, 12);
console.log("Sum is " + answer);
