var Car = /** @class */ (function () {
    function Car(model, color) {
        if (model === void 0) { model = "default model"; }
        if (color === void 0) { color = "default color"; }
        this.model = model;
        this.color = color;
        console.log("creating object ");
    }
    Car.prototype.getModelNumber = function () {
        console.log("Getting model number");
        return this.model;
    };
    return Car;
}());
// creating object
var car1 = new Car("TATA NEXON", "WHITE");
var car2 = new Car("TATA TIAGO", "BLACK");
var car3 = new Car(undefined, "GRAY");
console.log(car1);
console.log(car2);
console.log(car3);
