interface Employee {
  empName: string;
  empId: string;
  phone: number;
  getInfo: () => string;
}

function getInformation(employee: Employee) {
  console.log("name : " + employee.empName);
  console.log("id : " + employee.empId);
  console.log("phone : " + employee.phone);
  employee.getInfo();
}

let ob = {
  empName: "Durgesh",
  empId: "12354312",
  phone: 21235,
  getInfo: () => {
    console.log("information from object");

    return "this is information from object";
  },
};
getInformation(ob);
