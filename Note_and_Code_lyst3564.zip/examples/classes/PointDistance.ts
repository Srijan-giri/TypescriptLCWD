interface Point {
  x: number;
  y: number;
  displayCoordinates(): void;
}

class PointImpl implements Point {
  x: number;
  y: number;

  constructor(x: number, y: number) {
    this.x = x;
    this.y = y;
  }

  displayCoordinates(): void {
    console.log(`( ${this.x} , ${this.y} )`);
  }
}

function findDistance(point1: Point, point2: Point): void {
  point1.displayCoordinates();
  point2.displayCoordinates();
  // calculate the distance
  let yR = Math.pow(point2.y - point1.y, 2);
  let xR = Math.pow(point2.x - point1.x, 2);
  let d = Math.sqrt(xR + yR);
  console.log("Distance : " + d.toFixed(2));
}

// calling the method to calculate the distance
findDistance(new PointImpl(-7, -4), new PointImpl(17, 6.5));
findDistance(new PointImpl(10, -4), new PointImpl(45, 6.5));
