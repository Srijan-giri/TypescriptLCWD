function getInformation(employee) {
    console.log("name : " + employee.empName);
    console.log("id : " + employee.empId);
    console.log("phone : " + employee.phone);
    employee.getInfo();
}
var ob = {
    empName: "Durgesh",
    empId: "12354312",
    phone: 21235,
    getInfo: function () {
        console.log("information from object");
        return "this is information from object";
    },
};
getInformation(ob);
