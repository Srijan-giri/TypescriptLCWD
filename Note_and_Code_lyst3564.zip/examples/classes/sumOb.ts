class Sum {
  private _a: number;
  private _b: number;

  constructor(a: number, b: number) {
    if (this._a < 0 || this._b < 0) {
      console.log("Negative values not allowed !!");
      throw new Error("Error in creating Object : No Negative values allowed");
    }
    this._a = a;
    this._b = b;
    console.log("Creating object of sum");
  }

  //setters
  set a(a: number) {
    console.log("Setter a");

    if (this._a < 0) {
      console.log("Only positive values are allowed !!");
      return;
    }
    this._a = a;
  }

  set b(b: number) {
    console.log("setter b");

    if (this._b < 0) {
      console.log("Only positive values are allowed !!");
      return;
    }
    this._b = b;
  }

  //getters
  get a() {
    // any validation
    console.log("Validating a");

    return this._a;
  }

  get b() {
    //any validation
    console.log("validating b");

    return this._b;
  }

  sum() {
    return this._a + this._b;
  }

  display() {
    console.log("Value of a ", this.a);
    console.log("Value of b ", this.b);
  }
}

let ob = new Sum(34, 45);

ob.display();

ob.a = -9056;
ob.b = 34534;

ob.display();

console.log(ob.a);
console.log(ob.b);
