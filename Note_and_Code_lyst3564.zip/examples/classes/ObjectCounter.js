var Car = /** @class */ (function () {
    function Car() {
        Car.count++;
    }
    Car.count = 0;
    return Car;
}());
var ob1 = new Car();
var ob2 = new Car();
var ob3 = new Car();
console.log("Number of objects " + Car.count);
var ob4 = new Car();
console.log("Number of objects " + Car.count);
