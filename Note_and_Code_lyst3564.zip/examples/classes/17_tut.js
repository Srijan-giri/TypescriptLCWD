var Car = /** @class */ (function () {
    function Car(color) {
        this.color = color;
        console.log("creating car object");
    }
    //   methods
    Car.prototype.start = function () {
        console.log("starting car");
    };
    Car.prototype.sumTwoNumber = function (a, b) {
        console.log("Adding two number");
        return a + b;
    };
    return Car;
}());
//creating object
var ob1 = new Car("Black");
console.log(ob1.color);
ob1.start();
var answer = ob1.sumTwoNumber(34, 12);
console.log("Sum is " + answer);
