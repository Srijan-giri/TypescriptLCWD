class Car {
  private _color: string;
  protected _model: string;

  constructor(color: string, model: string) {
    this._color = color;
    this._model = model;
  }

  //   getters and setters

  display() {
    console.log("Color is ", this._color);
    console.log("Model number is ", this._model);

    this.displayInternal();
  }

  private displayInternal() {
    console.log("Display internal details");
  }
}

class ChildCar extends Car {
  constructor(color: string, model: string) {
    super(color, model);
  }

  displayChild(): void {
    console.log("Displaying model from child  ", this._model);
  }
}

let ob = new Car("WHITE", "TIGAO24");

// console.log(ob._color);
// ob._color = "BLACK";
// console.log(ob._color);

ob.display();

let obChild = new ChildCar("BLACK", "NEXON");
obChild.displayChild();
