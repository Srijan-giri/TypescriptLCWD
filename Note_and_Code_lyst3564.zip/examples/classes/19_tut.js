var Student = /** @class */ (function () {
    function Student(college) {
        this._college = college;
    }
    return Student;
}());
var student1 = new Student("IIT KANPUR");
console.log(student1._college);
// student1._college="IIT DELHI";
