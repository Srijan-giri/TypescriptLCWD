class Student {
  readonly _college: string;

  constructor(college: string) {
    this._college = college;
  }
}

let student1 = new Student("IIT KANPUR");

console.log(student1._college);

// student1._college="IIT DELHI";
