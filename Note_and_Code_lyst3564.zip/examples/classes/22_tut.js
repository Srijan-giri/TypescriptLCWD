var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Employee = /** @class */ (function () {
    function Employee(name, empId) {
        this.name = name;
        this.empId = empId;
        console.log("Prarent contstructor");
    }
    Employee.prototype.displayDetails = function () {
        console.log("name : ".concat(this.name, ", empId : ").concat(this.empId));
    };
    return Employee;
}());
var Manager = /** @class */ (function (_super) {
    __extends(Manager, _super);
    // name: string = "new name";
    function Manager(name, empId, task) {
        var _this = _super.call(this, name, empId) || this;
        _this.task = task;
        console.log("Child contrcutor");
        return _this;
    }
    Manager.prototype.displayAllData = function () {
        _super.prototype.displayDetails.call(this);
        console.log("task is " + this.task);
        // console.log(this.name);
        // console.log(super.name);
        // console.log(super.name);
    };
    return Manager;
}(Employee));
var emp = new Manager("Harsh", "235235", "Teaching Java");
emp.displayAllData();
