var Demo = /** @class */ (function () {
    function Demo() {
    }
    Demo.myMethod = function () {
        console.log("Calling static method");
    };
    Demo.prototype.myStaticTest = function () {
        console.log(this.name);
        console.log(Demo.college);
    };
    return Demo;
}());
var ob1 = new Demo();
ob1.name = "OB1";
var ob2 = new Demo();
ob2.name = "OB2";
Demo.college = "IIT KANPUR";
Demo.myMethod();
ob1.myStaticTest();
