class Employee {
  name: string;
  empId: string;
  constructor(name: string, empId: string) {
    this.name = name;
    this.empId = empId;
    console.log("Prarent contstructor");
  }

  displayDetails() {
    console.log(`name : ${this.name}, empId : ${this.empId}`);
  }
}

class Manager extends Employee {
  task: string;
  // name: string = "new name";

  constructor(name: string, empId: string, task: string) {
    super(name, empId);
    this.task = task;
    console.log("Child contrcutor");
  }

  displayAllData() {
    super.displayDetails();
    console.log("task is " + this.task);

    // console.log(this.name);
    // console.log(super.name);
    // console.log(super.name);
  }
}

let emp = new Manager("Harsh", "235235", "Teaching Java");
emp.displayAllData();
