class Demo {
  // static variable- this variable is shared by all objects
  static college: string;

  // instance variable- copy of this variable is provided to object
  name: string;

  static myMethod() {
    console.log("Calling static method");
  }

  myStaticTest() {
    console.log(this.name);
    console.log(Demo.college);
  }
}

let ob1 = new Demo();

ob1.name = "OB1";

let ob2 = new Demo();

ob2.name = "OB2";

Demo.college = "IIT KANPUR";
Demo.myMethod();

ob1.myStaticTest();
