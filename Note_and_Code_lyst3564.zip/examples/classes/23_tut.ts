class Parent {
  greet() {
    console.log("how are you, I am parent");
  }
}

class Child extends Parent {
  greet() {
    console.warn(" i am child , how are you");
  }
}

let ob = new Child();

ob.greet();
