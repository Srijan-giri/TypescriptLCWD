interface Employee {
  empName: string;
  empId: string;
  phone: number;
  getInfo: () => string;
}

class Manager implements Employee {
  empName: string;
  empId: string;
  phone: number;

  constructor(empName: string, empId: string, phone: number) {
    this.empName = empName;
    (this.empId = empId), (this.phone = phone);
  }

  getInfo = () => {
    console.log("getting value from manager");
    return this.empName + " : " + this.empId;
  };
}

function getInformation(employee: Employee) {
  console.log("name : " + employee.empName);
  console.log("id : " + employee.empId);
  console.log("phone : " + employee.phone);
  console.log(employee.getInfo());
}

let manager = new Manager("Durgesh", "6235256", 2352);
getInformation(manager);

getInformation(new Manager("Ankit", "w2525", 254));
