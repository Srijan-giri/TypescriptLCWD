class Car {
  //variables

  model: string;

  color: string;

  constructor(
    model: string = "default model",
    color: string = "default color"
  ) {
    this.model = model;
    this.color = color;
    console.log("creating object ");
  }

  getModelNumber(): string {
    console.log("Getting model number");
    return this.model;
  }
}

// creating object

let car1: Car = new Car("TATA NEXON", "WHITE");

let car2 = new Car("TATA TIAGO", "BLACK");

let car3 = new Car(undefined, "GRAY");

console.log(car1);

console.log(car2);

console.log(car3);
