var Manager = /** @class */ (function () {
    function Manager(empName, empId, phone) {
        var _this = this;
        this.getInfo = function () {
            console.log("getting value from manager");
            return _this.empName + " : " + _this.empId;
        };
        this.empName = empName;
        (this.empId = empId), (this.phone = phone);
    }
    return Manager;
}());
function getInformation(employee) {
    console.log("name : " + employee.empName);
    console.log("id : " + employee.empId);
    console.log("phone : " + employee.phone);
    console.log(employee.getInfo());
}
var manager = new Manager("Durgesh", "6235256", 2352);
getInformation(manager);
getInformation(new Manager("Ankit", "w2525", 254));
