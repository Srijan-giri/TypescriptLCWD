// shyam

let userEmail: string = "This is reigter field : email";

function validate() {
  console.log("validating register details");
}

class Test {}

export { userEmail, validate, Test };
