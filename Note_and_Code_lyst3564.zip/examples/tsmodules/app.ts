import { userEmail, validate, Test, userPassword } from "./login";
import { userEmail as rUserEmail, validate as rValidate } from "./register";
import WowFunction from "./login";
console.log(userEmail);
console.log(userPassword);
WowFunction();
validate();
console.log(rUserEmail);
rValidate();
