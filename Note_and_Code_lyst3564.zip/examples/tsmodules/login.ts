// Ram
let userEmail: string = "This is login field : email";
export let userPassword = "this is password";

function validate() {
  console.log("validating login details");
}

class Test {}

function wow() {
  console.log("wow of login");
}

export { userEmail, validate, Test };
export default wow;
