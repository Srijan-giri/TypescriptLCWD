"use strict";
// shyam
Object.defineProperty(exports, "__esModule", { value: true });
exports.Test = exports.validate = exports.userEmail = void 0;
var userEmail = "This is reigter field : email";
exports.userEmail = userEmail;
function validate() {
    console.log("validating register details");
}
exports.validate = validate;
var Test = /** @class */ (function () {
    function Test() {
    }
    return Test;
}());
exports.Test = Test;
