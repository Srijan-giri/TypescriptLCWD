"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Test = exports.validate = exports.userEmail = exports.userPassword = void 0;
// Ram
var userEmail = "This is login field : email";
exports.userEmail = userEmail;
exports.userPassword = "this is password";
function validate() {
    console.log("validating login details");
}
exports.validate = validate;
var Test = /** @class */ (function () {
    function Test() {
    }
    return Test;
}());
exports.Test = Test;
function wow() {
    console.log("wow of login");
}
exports.default = wow;
