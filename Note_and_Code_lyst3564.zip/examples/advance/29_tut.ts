interface User {
  name: string;
  email: string;
  phone: string;
}

class MyProgram<T> {
  user: T;
  displayDetail() {
    console.log(this.user);
    console.log(typeof this.user);
  }
}

let ob: MyProgram<string> = new MyProgram();
ob.user = "durgesh kumar tiwari";
ob.displayDetail();

let ob1: MyProgram<User> = new MyProgram();
ob1.user = {
  name: "durgesh1",
  email: "durgesh@dev.in",
  phone: "213525235",
};
ob1.displayDetail();
