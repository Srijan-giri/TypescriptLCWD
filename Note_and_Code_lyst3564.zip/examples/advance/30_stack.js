var Stack = /** @class */ (function () {
    function Stack(size) {
        this.items = [];
        this.size = size;
    }
    Stack.prototype.isEmpty = function () {
        if (this.items.length === 0)
            return true;
        return false;
    };
    Stack.prototype.isFull = function () {
        if (this.items.length === this.size)
            return true;
        return false;
    };
    Stack.prototype.insert = function (element) {
        if (!this.isFull()) {
            this.items.push(element);
        }
        else {
            console.log("Stack is full");
        }
    };
    Stack.prototype.remove = function () {
        if (!this.isEmpty()) {
            return this.items.pop();
        }
        else {
            throw new Error("Stack is empty");
        }
    };
    Stack.prototype.display = function () {
        this.items.forEach(function (element) {
            console.log(element);
        });
    };
    return Stack;
}());
// let stack: Stack<number> = new Stack<number>(4);
// stack.insert(23);
// stack.insert(12);
// stack.insert(324);
// stack.display();
// console.log("removing");
// console.log(stack.remove());
// stack.display();
var stack = new Stack(2);
stack.insert("harsh");
stack.insert("durgesh");
stack.display();
