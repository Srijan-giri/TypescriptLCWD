interface Pair<U, V> {
  value1: U;
  value2: V;
}

function getPairInformation(pair: Pair<string, string>) {
  console.log(pair);
}
function getPairInformation1(pair: Pair<string, number>) {
  console.log(pair);
}

//calling the function

getPairInformation({
  value1: "this is testing",
  value2: "this is testing",
});

getPairInformation1({
  value1: "this is another string",
  value2: 242,
});
