interface MyType {
  name: string;
}

interface MyType1 {
  email: string;
}

// Generic Functions
function getInfo<T>(numbers: T[]) {
  console.log(numbers[1]);
}

function merge<U, V>(ob1: U, ob2: V) {
  console.log({
    ...ob1,
    ...ob2,
  });
}

getInfo<string>(["one", "two"]);
getInfo<number>([1, 2]);
getInfo<boolean>([true, false]);
getInfo<MyType>([{ name: "test" }, { name: "test" }]);
merge<MyType, MyType1>({ name: "test" }, { email: "test@gmail.com" });
