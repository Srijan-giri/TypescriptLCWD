class Employee {
  name: string;
  email: string;
}

class Manager extends Employee {}
class AndroidDeveloper extends Employee {}
class Animal {}

function getInformation<T extends Employee>(ob: T) {
  console.log(ob);
}

class Test<T extends Employee> {
  ob: T;
  wow() {
    console.log(this.ob);
  }
}

// call function
getInformation(new Manager());
