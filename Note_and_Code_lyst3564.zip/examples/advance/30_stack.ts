class Stack<T> {
  items: T[] = [];
  size: number;

  constructor(size: number) {
    this.size = size;
  }

  isEmpty() {
    if (this.items.length === 0) return true;

    return false;
  }

  isFull() {
    if (this.items.length === this.size) return true;
    return false;
  }

  insert(element: T) {
    if (!this.isFull()) {
      this.items.push(element);
    } else {
      console.log("Stack is full");
    }
  }

  remove(): T | undefined {
    if (!this.isEmpty()) {
      return this.items.pop();
    } else {
      throw new Error("Stack is empty");
    }
  }

  display() {
    this.items.forEach((element) => {
      console.log(element);
    });
  }
}

// let stack: Stack<number> = new Stack<number>(4);
// stack.insert(23);
// stack.insert(12);
// stack.insert(324);
// stack.display();
// console.log("removing");
// console.log(stack.remove());
// stack.display();
let stack: Stack<string> = new Stack(2);
stack.insert("harsh");
stack.insert("durgesh");
stack.display();
