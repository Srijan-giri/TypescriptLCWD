var MyProgram = /** @class */ (function () {
    function MyProgram() {
    }
    MyProgram.prototype.displayDetail = function () {
        console.log(this.user);
        console.log(typeof this.user);
    };
    return MyProgram;
}());
var ob = new MyProgram();
ob.user = "durgesh kumar tiwari";
ob.displayDetail();
var ob1 = new MyProgram();
ob1.user = {
    name: "durgesh1",
    email: "durgesh@dev.in",
    phone: "213525235",
};
ob1.displayDetail();
