var num;
console.log(num);
if (undefined) {
    console.log("TRUE");
}
else {
    console.log("False");
}
