# Interfaces

TypeScript interfaces define the contracts within your code. They also provide explicit names for type checking.

```ts
interface Parent {
  //fields
  //methods
}
```
